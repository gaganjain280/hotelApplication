package com.hotelApplication.model;

public class Booking {
    public String hotelId;
    public String arrival;
    public String departure;
    public String roomType;
    public String roomRate;
}