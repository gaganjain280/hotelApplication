package com.hotelApplication.model;

public class Room {
    public String roomType;
    public String roomId;
}
