package com.hotelApplication.model;

import java.util.List;

public class Hotel {
    public String id;
    public String name;
    public List<RoomType> roomTypes;
    public List<Room> rooms;
}