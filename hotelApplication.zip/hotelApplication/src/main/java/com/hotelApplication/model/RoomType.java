package com.hotelApplication.model;

import java.util.List;

public class RoomType {
    public String code;
    public String description;
    public List<String> amenities;
    public List<String> features;
}