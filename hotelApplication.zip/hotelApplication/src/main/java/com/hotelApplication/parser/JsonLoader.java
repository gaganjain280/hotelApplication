package com.hotelApplication.parser;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.hotelApplication.model.Booking;
import com.fasterxml.jackson.core.type.TypeReference;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public class JsonLoader {
    public static List<com.hotelApplication.model.Hotel> loadHotels(Path path) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(path.toFile(), new TypeReference<List<com.hotelApplication.model.Hotel>>() {
        });
    }

    public static List<Booking> loadBookings(Path path) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(path.toFile(), new TypeReference<List<Booking>>() {
        });
    }
}