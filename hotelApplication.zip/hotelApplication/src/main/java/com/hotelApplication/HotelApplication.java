package com.hotelApplication;

import com.hotelApplication.parser.JsonLoader;
import com.hotelApplication.service.HotelService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.nio.file.Paths;
import java.util.Scanner;

@SpringBootApplication
public class HotelApplication implements CommandLineRunner {

    private HotelService hotelService;

    public static void main(String[] args) {
        SpringApplication.run(HotelApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        if (args.length != 4 || !args[0].equals("--hotels") || !args[2].equals("--bookings")) {
            System.out.println("Usage: java -jar app.jar --hotels hotels.json --bookings bookings.json");
            return;
        }

        String hotelFile = args[1];
        String bookingFile = args[3];

        hotelService = new HotelService(
                JsonLoader.loadHotels(Paths.get(hotelFile)),
                JsonLoader.loadBookings(Paths.get(bookingFile))
        );

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter command:");
        while (true) {
            String input = scanner.nextLine().trim();
            if (input.isEmpty()) break;
            try {
                if (input.startsWith("Availability")) {
                    System.out.println(hotelService.checkAvailability(input));
                } else if (input.startsWith("Search")) {
                    System.out.println(hotelService.searchAvailability(input));
                } else {
                    System.out.println("Invalid command");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}


