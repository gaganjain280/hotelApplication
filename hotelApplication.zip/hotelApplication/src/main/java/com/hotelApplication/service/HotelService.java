package com.hotelApplication.service;
import com.hotelApplication.model.Booking;
import com.hotelApplication.util.DateUtil;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class HotelService {

    private final List<com.hotelApplication.model.Hotel> hotels;
    private final List<Booking> bookings;

    public HotelService(List<com.hotelApplication.model.Hotel> hotels, List<Booking> bookings) {
        this.hotels = hotels;
        this.bookings = bookings;
    }

    public String checkAvailability(String input) {
        String params = input.substring("Availability(".length(), input.length() - 1);
        String[] parts = params.split(",");
        String hotelId = parts[0].trim();
        String datePart = parts[1].trim();
        String roomType = parts[2].trim();

        LocalDate start;
        LocalDate end;

        if (datePart.contains("-")) {
            String[] dates = datePart.split("-");
            start = DateUtil.parse(dates[0]);
            end = DateUtil.parse(dates[1]);
        } else {
            start = DateUtil.parse(datePart);
            end = start.plusDays(1);
        }

        com.hotelApplication.model.Hotel hotel = hotels.stream().filter(h -> h.id.equals(hotelId)).findFirst().orElse(null);
        if (hotel == null) return "Hotel not found";

        long totalRooms = hotel.rooms.stream().filter(r -> r.roomType.equals(roomType)).count();

        Map<LocalDate, Long> dateBookings = new HashMap<>();
        for (Booking b : bookings) {
            if (b.hotelId.equals(hotelId) && b.roomType.equals(roomType)) {
                LocalDate bStart = DateUtil.parse(b.arrival);
                LocalDate bEnd = DateUtil.parse(b.departure);
                for (LocalDate d = bStart; d.isBefore(bEnd); d = d.plusDays(1)) {
                    if (!d.isBefore(start) && d.isBefore(end)) {
                        dateBookings.put(d, dateBookings.getOrDefault(d, 0L) + 1);
                    }
                }
            }
        }

        long minAvailable = totalRooms;
        for (LocalDate d = start; d.isBefore(end); d = d.plusDays(1)) {
            long booked = dateBookings.getOrDefault(d, 0L);
            minAvailable = Math.min(minAvailable, totalRooms - booked);
        }

        return String.valueOf(minAvailable);
    }

    public String searchAvailability(String input) {
        String params = input.substring("Search(".length(), input.length() - 1);
        String[] parts = params.split(",");
        String hotelId = parts[0].trim();
        int days = Integer.parseInt(parts[1].trim());
        String roomType = parts[2].trim();

        com.hotelApplication.model.Hotel hotel = hotels.stream().filter(h -> h.id.equals(hotelId)).findFirst().orElse(null);
        if (hotel == null) return "";

        long totalRooms = hotel.rooms.stream().filter(r -> r.roomType.equals(roomType)).count();
        Map<LocalDate, Long> dateBookings = new HashMap<>();

        for (Booking b : bookings) {
            if (b.hotelId.equals(hotelId) && b.roomType.equals(roomType)) {
                LocalDate bStart = DateUtil.parse(b.arrival);
                LocalDate bEnd = DateUtil.parse(b.departure);
                for (LocalDate d = bStart; d.isBefore(bEnd); d = d.plusDays(1)) {
                    dateBookings.put(d, dateBookings.getOrDefault(d, 0L) + 1);
                }
            }
        }

        LocalDate today = LocalDate.now();
        List<String> results = new ArrayList<>();
        LocalDate windowStart = null;
        int available = 0;

        for (LocalDate d = today; d.isBefore(today.plusDays(days)); d = d.plusDays(1)) {
            long booked = dateBookings.getOrDefault(d, 0L);
            int avail = (int) (totalRooms - booked);
            if (avail > 0) {
                if (windowStart == null) {
                    windowStart = d;
                    available = avail;
                } else {
                    available = Math.min(available, avail);
                }
            } else {
                if (windowStart != null) {
                    results.add(String.format("(%s-%s, %d)", DateUtil.format(windowStart), DateUtil.format(d), available));
                    windowStart = null;
                }
            }
        }

        if (windowStart != null) {
            results.add(String.format("(%s-%s, %d)", DateUtil.format(windowStart), DateUtil.format(today.plusDays(days)), available));
        }

        return String.join(", ", results);
    }
}